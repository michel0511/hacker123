# Getting started with Claudia Bot Builder

This page has moved to [https://claudiajs.com/tutorials/hello-world-chatbot.html](https://claudiajs.com/tutorials/hello-world-chatbot.html)
