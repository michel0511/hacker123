module.exports = require('./lib/bot-builder');
